# Heedartv Phase 1 — Brand foundation

This phase keeps OwnTV's Kotlin/Compose TV player, source integrations, database, and playback engines intact.

## Changes
- The existing launcher label is already `HEEDAR TV` in `app/src/main/res/values/strings.xml`.
- On the first launch of this branded build only, if the user has not configured a custom accent and the stored preset is still OwnTV's default teal, the app changes the accent preset to green.
- The migration is guarded by the app-private preference `heedartv_brand/green_accent_applied_v1`, so later launches do not overwrite a user's chosen theme colour.
- Existing custom accent choices are preserved.

## Deliberately unchanged
- `applicationId` (`tv.own.owntv`) and Kotlin namespace.
- Database and persisted user data.
- M3U, Xtream, Stalker, EPG and sync integrations.
- ExoPlayer/libmpv playback engines and player code.
- Existing screens and navigation.

## Validation status
- Source-level patch applied and reviewed.
- APK build and device testing have NOT been performed in this environment.
- This is a small brand-foundation phase, not the complete cinematic home redesign.

## Build
Use the repository's existing GitHub Actions workflow or Android build instructions. Do not change package ID or signing configuration as part of this phase.
